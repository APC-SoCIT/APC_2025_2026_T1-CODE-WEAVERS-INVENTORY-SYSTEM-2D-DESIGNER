import requests
import urllib3
from django.core.management.base import BaseCommand
from ecom.models import Region, Province, CityMunicipality, Barangay

# Disable insecure request warnings since we're using verify=False
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class Command(BaseCommand):
    help = 'Import PSGC data from https://psgc.rootscratch.com/ into local database'

    def handle(self, *args, **kwargs):
        self.stdout.write('Starting import of PSGC data...')

        # Import Regions
        regions_url = 'https://psgc.rootscratch.com/regions'
        regions_response = requests.get(regions_url, verify=False)
        if regions_response.status_code == 200:
            regions_data = regions_response.json()
            for region in regions_data:
                obj, created = Region.objects.update_or_create(
                    code=region['code'],
                    defaults={'name': region['name']}
                )
                if created:
                    self.stdout.write(f'Created Region: {obj.name}')
        else:
            self.stdout.write('Failed to fetch regions data')

        # Import Provinces
        provinces_url = 'https://psgc.rootscratch.com/provinces'
        provinces_response = requests.get(provinces_url, verify=False)
        if provinces_response.status_code == 200:
            provinces_data = provinces_response.json()
            for province in provinces_data:
                obj, created = Province.objects.update_or_create(
                    code=province['code'],
                    defaults={
                        'name': province['name'],
                        'region_code': province['region_code']
                    }
                )
                if created:
                    self.stdout.write(f'Created Province: {obj.name}')
        else:
            self.stdout.write('Failed to fetch provinces data')

        # Import Cities/Municipalities
        cities_url = 'https://psgc.rootscratch.com/cities-municipalities'
        cities_response = requests.get(cities_url, verify=False)
        if cities_response.status_code == 200:
            cities_data = cities_response.json()
            for city in cities_data:
                obj, created = CityMunicipality.objects.update_or_create(
                    code=city['code'],
                    defaults={
                        'name': city['name'],
                        'province_code': city.get('province_code'),
                        'region_code': city['region_code']
                    }
                )
                if created:
                    self.stdout.write(f'Created City/Municipality: {obj.name}')
        else:
            self.stdout.write('Failed to fetch cities/municipalities data')

        # Import Barangays
        barangays_url = 'https://psgc.rootscratch.com/barangays'
        barangays_response = requests.get(barangays_url, verify=False)
        if barangays_response.status_code == 200:
            barangays_data = barangays_response.json()
            for barangay in barangays_data:
                obj, created = Barangay.objects.update_or_create(
                    code=barangay['code'],
                    defaults={
                        'name': barangay['name'],
                        'city_code': barangay['city_code']
                    }
                )
                if created:
                    self.stdout.write(f'Created Barangay: {obj.name}')
        else:
            self.stdout.write('Failed to fetch barangays data')

        self.stdout.write('PSGC data import completed')
