from django.apps import AppConfig


class EcomConfig(AppConfig):
    name = 'ecom'


class JerseyCustomizerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'jersey_customizer'
