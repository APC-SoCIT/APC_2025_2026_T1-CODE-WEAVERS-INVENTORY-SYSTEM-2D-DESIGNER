from django.db import models
from django.contrib.auth.models import User
# Create your models here.
class Customer(models.Model):
    REGION_CHOICES = [
        ('01', 'REGION I (ILOCOS REGION)'),
        ('02', 'REGION II (CAGAYAN VALLEY)'),
        ('03', 'REGION III (CENTRAL LUZON)'),
        ('04', 'REGION IV-A (CALABARZON)'),
        ('17', 'REGION IV-B (MIMAROPA)'),
        ('05', 'REGION V (BICOL REGION)'),
        ('06', 'REGION VI (WESTERN VISAYAS)'),
        ('07', 'REGION VII (CENTRAL VISAYAS)'),
        ('08', 'REGION VIII (EASTERN VISAYAS)'),
        ('09', 'REGION IX (ZAMBOANGA PENINSULA)'),
        ('10', 'REGION X (NORTHERN MINDANAO)'),
        ('11', 'REGION XI (DAVAO REGION)'),
        ('12', 'REGION XII (SOCCSKSARGEN)'),
        ('13', 'NATIONAL CAPITAL REGION (NCR)'),
        ('14', 'CORDILLERA ADMINISTRATIVE REGION (CAR)'),
        ('15', 'AUTONOMOUS REGION IN MUSLIM MINDANAO (ARMM)'),
        ('16', 'REGION XIII (Caraga)'),
    ]
    
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    profile_pic = models.ImageField(upload_to='profile_pic/CustomerProfilePic/', null=True, blank=True)
    region = models.CharField(max_length=2, choices=REGION_CHOICES)
    province = models.CharField(max_length=100, blank=True, null=True)
    citymun = models.CharField(max_length=100, blank=True, null=True)
    barangay = models.CharField(max_length=100, blank=True, null=True)
    street_address = models.CharField(max_length=100)
    postal_code = models.PositiveIntegerField()
    mobile = models.CharField(max_length=13, help_text="Enter 10 digits, e.g. '956 837 0169'")

    @property
    def get_full_address(self):
        try:
            from ecom.utils import get_region_name, get_province_name, get_citymun_name, get_barangay_name
            region_name = get_region_name(self.region) if self.region else ''
            province_name = get_province_name(self.province) if self.province else ''
            citymun_name = get_citymun_name(self.citymun) if self.citymun else ''
            barangay_name = get_barangay_name(self.barangay) if self.barangay else ''
            return f"{self.street_address}, {barangay_name}, {citymun_name}, {province_name}, {region_name}, {self.postal_code}"
        except (KeyError, AttributeError):
            return f"{self.street_address}, {self.barangay}, {self.citymun}, {self.province}, {self.postal_code}"

    def __str__(self):
        return self.user.first_name

    @property
    def customer_code(self):
        # Format user id with prefix and zero padding, e.g. CUST000123
        return f"CUST{self.user.id:06d}"

    @property
    def status(self):
        return "Active" if self.user.is_active else "Inactive"


class InventoryItem(models.Model):
    name = models.CharField(max_length=50)
    quantity = models.PositiveIntegerField(default=0)
    description = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.name


class Product(models.Model):
    name = models.CharField(max_length=40)
    product_image = models.ImageField(upload_to='product_image/', null=True, blank=True)
    price = models.PositiveIntegerField()
    description = models.CharField(max_length=40)
    quantity = models.PositiveIntegerField(default=0)
    SIZE_CHOICES = (
        ('S', 'Small'),
        ('XS', 'Extra Small'),
        ('M', 'Medium'),
        ('L', 'Large'),
        ('XL', 'Extra Large'),
    )
    size = models.CharField(max_length=2, choices=SIZE_CHOICES, default='M')
    
    def __str__(self):
        return self.name

    def get_size_stock(self):
        stock = {size: 0 for size, _ in self.SIZE_CHOICES}
        for size, _ in self.SIZE_CHOICES:
            item = InventoryItem.objects.filter(name=f"{self.name} - {size}").first()
            if item:
                stock[size] = item.quantity
            elif self.size == size:
                stock[size] = self.quantity
        return stock

    def get_size_stock_json(self):
        import json
        return json.dumps(self.get_size_stock())

class CartItem(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    size = models.CharField(max_length=5, choices=Product.SIZE_CHOICES)
    quantity = models.PositiveIntegerField(default=1)



class Orders(models.Model):
    STATUS = (
        ('Pending', 'Pending - Awaiting Payment'),
        ('Processing', 'Processing - Payment Confirmed'),
        ('Order Confirmed', 'Order Confirmed - In Production'),
        ('Out for Delivery', 'Out for Delivery'),
        ('Delivered', 'Delivered'),
        ('Cancelled', 'Cancelled')
    )
    PAYMENT_METHODS = (
        ('cod', 'Cash on Delivery'),
        ('paypal', 'PayPal')
    )
    created_at = models.DateTimeField(auto_now_add=True, help_text='When the order was created')
    updated_at = models.DateTimeField(auto_now=True, help_text='When the order was last updated')
    customer = models.ForeignKey('Customer', on_delete=models.CASCADE, null=True)
    product = models.ForeignKey('Product', on_delete=models.CASCADE, null=True)
    email = models.CharField(max_length=50, null=True)
    address = models.CharField(max_length=500, null=True)
    mobile = models.CharField(max_length=20, null=True)
    order_date = models.DateField(auto_now_add=True, null=True, help_text='Date when order was placed')
    status = models.CharField(max_length=50, null=True, choices=STATUS, default='Pending', help_text='Current status of the order')
    status_updated_at = models.DateTimeField(null=True, blank=True, help_text='When the status was last changed')
    size = models.CharField(max_length=20)
    quantity = models.IntegerField(default=1)
    estimated_delivery_date = models.DateField(null=True, blank=True, help_text='Estimated delivery date')
    notes = models.TextField(blank=True, null=True, help_text='Additional notes about the order')
    payment_method = models.CharField(max_length=10, choices=PAYMENT_METHODS, default='cod', help_text='Payment method for the order')
    order_ref = models.CharField(max_length=12, unique=True, null=True, blank=True, help_text='Unique short order reference ID')

class OrderItem(models.Model):
    order = models.ForeignKey(Orders, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.IntegerField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    size = models.CharField(max_length=5, choices=Product.SIZE_CHOICES, null=True, blank=True)


class Feedback(models.Model):
    name=models.CharField(max_length=40)
    feedback=models.CharField(max_length=500)
    date= models.DateField(auto_now_add=True,null=True)

    def __str__(self):
        return self.name


# Address model for admin system
class SavedAddress(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='saved_addresses')
    is_default = models.BooleanField(default=False)
    full_name = models.CharField(max_length=100)
    phone = models.CharField(max_length=20)
    region = models.CharField(max_length=2, choices=Customer.REGION_CHOICES)
    province = models.CharField(max_length=100)
    citymun = models.CharField(max_length=100)
    barangay = models.CharField(max_length=100)
    street_address = models.CharField(max_length=255)
    postal_code = models.CharField(max_length=20)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-is_default', '-updated_at']

    def __str__(self):
        return f"{self.full_name} - {self.street_address}, {self.barangay}, {self.citymun}, {self.province}, {self.region}, {self.postal_code}"

    def save(self, *args, **kwargs):
        if self.is_default:
            # Set all other addresses of this customer to non-default
            SavedAddress.objects.filter(customer=self.customer).update(is_default=False)
        elif not SavedAddress.objects.filter(customer=self.customer).exists():
            # If this is the first address for the customer, make it default
            self.is_default = True
        super().save(*args, **kwargs)

class ShippingFee(models.Model):
    courier = models.CharField(max_length=50)
    origin_region = models.CharField(max_length=50)
    destination_region = models.CharField(max_length=50)
    weight_kg = models.DecimalField(max_digits=4, decimal_places=2)
    price_php = models.DecimalField(max_digits=8, decimal_places=2)

    def __str__(self):
        return f"{self.courier}: {self.origin_region} to {self.destination_region} ({self.weight_kg}kg) - ₱{self.price_php}"


