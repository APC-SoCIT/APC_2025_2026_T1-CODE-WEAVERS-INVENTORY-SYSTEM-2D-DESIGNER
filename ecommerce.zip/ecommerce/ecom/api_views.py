import requests
from django.http import JsonResponse
from django.views.decorators.http import require_GET
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
import logging
import urllib3

# Disable insecure request warnings since we're using verify=False
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logger = logging.getLogger(__name__)
PSGC_BASE_URL = "https://psgc.rootscratch.com"

def add_cors_headers(response):
    response["Access-Control-Allow-Origin"] = "*"
    response["Access-Control-Allow-Methods"] = "GET, OPTIONS"
    response["Access-Control-Allow-Headers"] = "Content-Type, X-Requested-With"
    return response

@csrf_exempt
@require_http_methods(["GET", "OPTIONS"])
def get_regions(request):
    if request.method == "OPTIONS":
        response = JsonResponse({})
        return add_cors_headers(response)

    try:
        region_id = request.GET.get('region_id')
        params = {"id": region_id} if region_id else {}
        logger.info(f"Fetching regions from {PSGC_BASE_URL}/region with params: {params}")
        
        # Log request headers for debugging
        logger.debug(f"Request headers: {dict(request.headers)}")
        
        response = requests.get(
            f"{PSGC_BASE_URL}/region",
            params=params,
            headers={
                'Accept': 'application/json',
                'User-Agent': 'Django/PSGC-Client'
            },
            timeout=10,
            verify=False  # Disable SSL verification
        )
        response.raise_for_status()
        data = response.json()
        
        # Log raw response data
        logger.debug(f"Raw response data: {data}")
        
        if not isinstance(data, list):
            logger.error(f"Invalid response format from PSGC API. Expected list but got {type(data)}")
            return add_cors_headers(JsonResponse({"error": "Invalid response format from PSGC API"}, status=500))
        
        # Transform the data to match the expected format
        regions = [{
            'psgc_code': region.get('psgc_id') or region.get('code'),
            'name': region.get('name') or region.get('regDesc'),
            'regDesc': region.get('name') or region.get('regDesc'),  # For backward compatibility
            'regCode': region.get('psgc_id') or region.get('code')  # For backward compatibility
        } for region in data]
        
        # Sort regions by name
        regions.sort(key=lambda x: x['name'])
        
        # Log transformed data
        logger.debug(f"Transformed regions data: {regions}")
        
        response = JsonResponse(regions, safe=False)
        return add_cors_headers(response)
    except requests.Timeout:
        logger.error("Timeout while fetching regions from PSGC API")
        response = JsonResponse({"error": "Request to PSGC API timed out"}, status=504)
        return add_cors_headers(response)
    except requests.RequestException as e:
        logger.error(f"Failed to fetch regions: {str(e)}")
        logger.error(f"Request URL: {PSGC_BASE_URL}/region")
        logger.error(f"Request params: {params}")
        response = JsonResponse({"error": f"Failed to fetch regions: {str(e)}"}, status=500)
        return add_cors_headers(response)
    except Exception as e:
        logger.error(f"Unexpected error while fetching regions: {str(e)}")
        logger.error(f"Request URL: {PSGC_BASE_URL}/region")
        logger.error(f"Request params: {params}")
        response = JsonResponse({"error": "An unexpected error occurred"}, status=500)
        return add_cors_headers(response)

@csrf_exempt
@require_http_methods(["GET", "OPTIONS"])
def get_provinces(request):
    if request.method == "OPTIONS":
        response = JsonResponse({})
        return add_cors_headers(response)

    region_id = request.GET.get('region_id')
    if not region_id:
        response = JsonResponse({"error": "region_id parameter is required"}, status=400)
        return add_cors_headers(response)

    try:
        response = requests.get(
            f"{PSGC_BASE_URL}/province",
            params={"id": region_id},
            headers={
                'Accept': 'application/json',
                'User-Agent': 'Django/PSGC-Client'
            },
            timeout=10,
            verify=False  # Disable SSL verification
        )
        response.raise_for_status()
        data = response.json()
        
        if not isinstance(data, list):
            logger.error(f"Invalid response format from PSGC API. Expected list but got {type(data)}")
            response = JsonResponse({"error": "Invalid response format from PSGC API"}, status=500)
            return add_cors_headers(response)
            
        # Sort provinces by name
        data.sort(key=lambda x: x.get('name', '') or x.get('provDesc', ''))
        
        response = JsonResponse(data, safe=False)
        return add_cors_headers(response)
    except requests.Timeout:
        response = JsonResponse({"error": "Request to PSGC API timed out"}, status=504)
        return add_cors_headers(response)
    except requests.RequestException as e:
        logger.error(f"Failed to fetch provinces: {str(e)}")
        response = JsonResponse({"error": "Failed to fetch provinces"}, status=500)
        return add_cors_headers(response)

@csrf_exempt
@require_http_methods(["GET", "OPTIONS"])
def get_cities(request):
    if request.method == "OPTIONS":
        response = JsonResponse({})
        return add_cors_headers(response)

    province_id = request.GET.get('province_id')
    region_id = request.GET.get('region_id')
    
    if not province_id and not region_id:
        response = JsonResponse({"error": "province_id or region_id parameter is required"}, status=400)
        return add_cors_headers(response)

    try:
        if province_id:
            response = requests.get(
                f"{PSGC_BASE_URL}/municipal-city",
                params={"id": province_id},
                headers={
                    'Accept': 'application/json',
                    'User-Agent': 'Django/PSGC-Client'
                },
                timeout=10,
                verify=False  # Disable SSL verification
            )
            response.raise_for_status()
            data = response.json()
            data.sort(key=lambda x: x.get('name', '') or x.get('citymunDesc', ''))
            response = JsonResponse(data, safe=False)
            return add_cors_headers(response)
        else:
            # Handle region_id case
            prov_response = requests.get(
                f"{PSGC_BASE_URL}/province",
                params={"id": region_id},
                headers={
                    'Accept': 'application/json',
                    'User-Agent': 'Django/PSGC-Client'
                },
                timeout=10,
                verify=False  # Disable SSL verification
            )
            prov_response.raise_for_status()
            provinces = prov_response.json()
            
            if not provinces:
                # Fallback: fetch all cities and filter by region code
                response = requests.get(
                    f"{PSGC_BASE_URL}/municipal-city",
                    headers={
                        'Accept': 'application/json',
                        'User-Agent': 'Django/PSGC-Client'
                    },
                    timeout=10,
                    verify=False  # Disable SSL verification
                )
                response.raise_for_status()
                data = response.json()
                filtered_cities = [city for city in data if city.get('regCode') == region_id or city.get('region_code') == region_id]
                filtered_cities.sort(key=lambda x: x.get('name', '') or x.get('citymunDesc', ''))
                response = JsonResponse(filtered_cities, safe=False)
                return add_cors_headers(response)
            
            all_cities = []
            for prov in provinces:
                city_response = requests.get(
                    f"{PSGC_BASE_URL}/municipal-city",
                    params={"id": prov.get('psgc_id') or prov.get('code')},
                    headers={
                        'Accept': 'application/json',
                        'User-Agent': 'Django/PSGC-Client'
                    },
                    timeout=10,
                    verify=False  # Disable SSL verification
                )
                city_response.raise_for_status()
                cities = city_response.json()
                all_cities.extend(cities)
            
            all_cities.sort(key=lambda x: x.get('name', '') or x.get('citymunDesc', ''))
            response = JsonResponse(all_cities, safe=False)
            return add_cors_headers(response)
    except requests.Timeout:
        response = JsonResponse({"error": "Request to PSGC API timed out"}, status=504)
        return add_cors_headers(response)
    except requests.RequestException as e:
        logger.error(f"Failed to fetch cities: {str(e)}")
        response = JsonResponse({"error": "Failed to fetch cities"}, status=500)
        return add_cors_headers(response)

@csrf_exempt
@require_http_methods(["GET", "OPTIONS"])
def get_barangays(request):
    if request.method == "OPTIONS":
        response = JsonResponse({})
        return add_cors_headers(response)

    city_id = request.GET.get('city_id')
    if not city_id:
        response = JsonResponse({"error": "city_id parameter is required"}, status=400)
        return add_cors_headers(response)

    try:
        response = requests.get(
            f"{PSGC_BASE_URL}/barangay",
            params={"id": city_id},
            headers={
                'Accept': 'application/json',
                'User-Agent': 'Django/PSGC-Client'
            },
            timeout=10,
            verify=False  # Disable SSL verification
        )
        response.raise_for_status()
        data = response.json()
        
        if not isinstance(data, list):
            logger.error(f"Invalid response format from PSGC API. Expected list but got {type(data)}")
            response = JsonResponse({"error": "Invalid response format from PSGC API"}, status=500)
            return add_cors_headers(response)
            
        # Sort barangays by name
        data.sort(key=lambda x: x.get('name', '') or x.get('brgyDesc', ''))
        
        response = JsonResponse(data, safe=False)
        return add_cors_headers(response)
    except requests.Timeout:
        response = JsonResponse({"error": "Request to PSGC API timed out"}, status=504)
        return add_cors_headers(response)
    except requests.RequestException as e:
        logger.error(f"Failed to fetch barangays: {str(e)}")
        response = JsonResponse({"error": "Failed to fetch barangays"}, status=500)
        return add_cors_headers(response)


# Utility functions for backend name resolution

def get_region_name(region_id):
    try:
        params = {"id": region_id} if region_id else {}
        response = requests.get(
            f"{PSGC_BASE_URL}/region",
            params=params,
            verify=False  # Disable SSL verification
        )
        response.raise_for_status()
        regions = response.json()
        for region in regions:
            if region.get('psgc_code') == region_id or region.get('code') == region_id:
                return region.get('name', region_id)
        return region_id
    except Exception:
        return region_id

def get_province_name(province_id):
    try:
        params = {"id": province_id} if province_id else {}
        response = requests.get(
            f"{PSGC_BASE_URL}/province",
            params=params,
            verify=False  # Disable SSL verification
        )
        response.raise_for_status()
        provinces = response.json()
        for province in provinces:
            if province.get('psgc_id') == province_id or province.get('code') == province_id:
                return province.get('name', province_id)
        return province_id
    except Exception:
        return province_id

def get_citymun_name(citymun_id):
    try:
        params = {"id": citymun_id} if citymun_id else {}
        response = requests.get(
            f"{PSGC_BASE_URL}/municipal-city",
            params=params,
            verify=False  # Disable SSL verification
        )
        response.raise_for_status()
        cities = response.json()
        for city in cities:
            if city.get('psgc_id') == citymun_id or city.get('code') == citymun_id:
                return city.get('name', citymun_id)
        return citymun_id
    except Exception:
        return citymun_id

def get_barangay_name(barangay_id):
    try:
        params = {"id": barangay_id} if barangay_id else {}
        response = requests.get(
            f"{PSGC_BASE_URL}/barangay",
            params=params,
            verify=False  # Disable SSL verification
        )
        response.raise_for_status()
        barangays = response.json()
        for barangay in barangays:
            if barangay.get('psgc_id') == barangay_id or barangay.get('code') == barangay_id:
                return barangay.get('name', barangay_id)
        return barangay_id
    except Exception:
        return barangay_id

