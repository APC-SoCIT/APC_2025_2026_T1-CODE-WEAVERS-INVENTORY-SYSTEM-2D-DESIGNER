// ph-address-cascade.js
// Dynamically populates Region, Province, City/Municipality, and Barangay dropdowns using PH address JSON files

window.initPHAddressCascade = function(config) {
  const regionSel = document.getElementById(config.region);
  const provinceSel = document.getElementById(config.province);
  const citymunSel = document.getElementById(config.citymun);
  const barangaySel = document.getElementById(config.barangay);
  const staticPath = config.staticPath;

  let regions = [], provinces = [], citymuns = [], barangays = [];

  // Helper: fetch and cache JSON
  async function fetchJSON(filename) {
    try {
      console.log('Fetching:', staticPath + filename);
      const res = await fetch(staticPath + filename);
      if (!res.ok) {
        throw new Error(`HTTP error! status: ${res.status}`);
      }
      const data = await res.json();
      console.log('Loaded data for:', filename, data);
      return data;
    } catch (error) {
      console.error('Error loading', filename + ':', error);
      return { RECORDS: [] };
    }
  }

  // Load all JSON files
  console.log('Initializing with config:', config);
  Promise.all([
    fetchJSON('refregion.json'),
    fetchJSON('refprovince.json'),
    fetchJSON('refcitymun.json'),
    fetchJSON('refbrgy.json')
  ]).then(function([regionData, provinceData, citymunData, brgyData]) {
    regions = regionData.RECORDS || regionData;
    provinces = provinceData.RECORDS || provinceData;
    citymuns = citymunData.RECORDS || citymunData;
    barangays = brgyData.RECORDS || brgyData;
    console.log('Loaded data:', {
      regions: regions.length,
      provinces: provinces.length,
      citymuns: citymuns.length,
      barangays: barangays.length
    });
    console.log('Sample data:', {
      region: regions[0],
      province: provinces[0],
      citymun: citymuns[0],
      barangay: barangays[0]
    });
    populateRegions();

    // Re-attach event listeners to ensure they're working
    if (regionSel && provinceSel && citymunSel) {
      console.log('Re-attaching event listeners');
      regionSel.addEventListener('change', onRegionChange);
      provinceSel.addEventListener('change', onProvinceChange);
      citymunSel.addEventListener('change', onCityMunChange);
    }
  }).catch(function(error) {
    console.error('Failed to load address data:', error);
  });

  function clearSelect(sel) {
    sel.innerHTML = '<option value="" disabled selected>Select</option>';
  }

  function populateRegions() {
    console.log('Populating regions');
    clearSelect(regionSel);
    clearSelect(provinceSel);
    clearSelect(citymunSel);
    clearSelect(barangaySel);
    regionSel.innerHTML = '<option value="" disabled selected>Select Region</option>';
    
    // Sort regions by regDesc
    const sortedRegions = [...regions].sort((a, b) => a.regDesc.localeCompare(b.regDesc));
    
    sortedRegions.forEach(function(region) {
      const opt = document.createElement('option');
      opt.value = region.regCode;
      opt.textContent = region.regDesc;
      regionSel.appendChild(opt);
      console.log('Added region:', region.regCode, region.regDesc);
    });

    // Add event listeners
    regionSel.addEventListener('change', onRegionChange);
    provinceSel.addEventListener('change', onProvinceChange);
    citymunSel.addEventListener('change', onCityMunChange);
    
    console.log('Region select populated with', sortedRegions.length, 'options');
  }

  function onRegionChange() {
    const regCode = regionSel.value;
    console.log('Region changed to:', regCode);
    
    clearSelect(provinceSel);
    clearSelect(citymunSel);
    clearSelect(barangaySel);
    
    provinceSel.innerHTML = '<option value="" disabled selected>Select Province</option>';
    
    // Filter and sort provinces by provDesc
    const filteredProvinces = provinces
      .filter(p => p.regCode === regCode)
      .sort((a, b) => a.provDesc.localeCompare(b.provDesc));
    
    console.log('Filtered provinces for region', regCode + ':', filteredProvinces);
    
    filteredProvinces.forEach(function(province) {
      const opt = document.createElement('option');
      opt.value = province.provCode;
      opt.textContent = province.provDesc;
      provinceSel.appendChild(opt);
      console.log('Added province:', province.provCode, province.provDesc);
    });
    
    console.log('Province select populated with', filteredProvinces.length, 'options');
  }

  function onProvinceChange() {
    const provCode = provinceSel.value;
    console.log('Province changed to:', provCode);
    
    clearSelect(citymunSel);
    clearSelect(barangaySel);
    
    citymunSel.innerHTML = '<option value="" disabled selected>Select City/Municipality</option>';
    
    // Filter and sort cities/municipalities by citymunDesc
    const filteredCitymuns = citymuns
      .filter(c => c.provCode === provCode)
      .sort((a, b) => a.citymunDesc.localeCompare(b.citymunDesc));
    
    console.log('Filtered cities/municipalities for province', provCode + ':', filteredCitymuns);
    
    filteredCitymuns.forEach(function(citymun) {
      const opt = document.createElement('option');
      opt.value = citymun.citymunCode;
      opt.textContent = citymun.citymunDesc;
      citymunSel.appendChild(opt);
      console.log('Added city/municipality:', citymun.citymunCode, citymun.citymunDesc);
    });
    
    console.log('City/Municipality select populated with', filteredCitymuns.length, 'options');
  }

  function onCityMunChange() {
    const citymunCode = citymunSel.value;
    console.log('City/Municipality changed to:', citymunCode);
    
    clearSelect(barangaySel);
    barangaySel.innerHTML = '<option value="" disabled selected>Select Barangay</option>';
    
    // Filter and sort barangays by brgyDesc
    const filteredBarangays = barangays
      .filter(b => b.citymunCode === citymunCode)
      .sort((a, b) => a.brgyDesc.localeCompare(b.brgyDesc));
    
    console.log('Filtered barangays for city/municipality', citymunCode + ':', filteredBarangays);
    
    filteredBarangays.forEach(function(brgy) {
      const opt = document.createElement('option');
      opt.value = brgy.brgyCode;
      opt.textContent = brgy.brgyDesc;
      barangaySel.appendChild(opt);
      console.log('Added barangay:', brgy.brgyCode, brgy.brgyDesc);
    });
    
    console.log('Barangay select populated with', filteredBarangays.length, 'options');
  }
}
